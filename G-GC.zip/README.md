# Genz-Giftcode-Recode v2.0.0

**Plugin Giftcode hiện đại với hỗ trợ Folia và Simple Key Validation**

## ✨ Tính năng

- ✅ **Hỗ trợ Folia & Paper** - Tương thích với Minecraft 1.20.4 - 1.21+
- ✅ **Simple Key Validation** - Bảo mật license đơn giản và hiệu quả
- ✅ **Ba loại Giftcode**: Normal, Random, Limit
- ✅ **GUI quản lý** - Giao diện trực quan để tạo/chỉnh sửa giftcode
- ✅ **Tích hợp kinh tế** - Hỗ trợ Vault (Money) và PlayerPoints
- ✅ **Kiểm tra IP** - Chống spam và lạm dụng
- ✅ **Yêu cầu thời gian online** - Kiểm soát người chơi mới
- ✅ **GitHub Key Validation** - Kiểm tra key qua GitHub để đảm bảo tính hợp lệ

## 🚀 Cài đặt

### 1. Yêu cầu hệ thống
- **Java**: 17+
- **Server**: Paper/Folia 1.20.4+
- **Plugins**: Vault (tùy chọn), PlayerPoints (tùy chọn)

### 2. Tải và cài đặt
1. Tải file `Genz-Giftcode-Recode-2.0.0.jar`
2. Đặt vào thư mục `plugins/`
3. Khởi động server để tạo file config
4. Dừng server và cấu hình license key

### 3. Cấu hình License

#### Bước 1: Nhận License Key
Liên hệ với nhà phát triển để nhận license key hợp lệ.

#### Bước 2: Cấu hình plugin
Mở `plugins/Genz-Giftcode-Recode/config.yml`:

```yaml
# Thay thế bằng license key thực của bạn
license: "YOUR_LICENSE_KEY_HERE"
```

#### Bước 3: Khởi động server
Plugin sẽ tự động kiểm tra license key qua GitHub khi khởi động.

## 📖 Hướng dẫn sử dụng

### Lệnh cơ bản

```
/giftcode help                    - Hiển thị trợ giúp
/giftcode create <code>           - Tạo giftcode normal
/giftcode create <code> random    - Tạo giftcode random  
/giftcode create <code> limit     - Tạo giftcode giới hạn
/giftcode edit <code>             - Chỉnh sửa giftcode
/giftcode list                    - Danh sách giftcode
/giftcode <code>                  - Sử dụng giftcode
/giftcode <code> <player>         - Tặng giftcode cho người chơi
/giftcode reload                  - Reload plugin
/giftcode license                 - Xem thông tin license
```

### Các loại Giftcode

#### 1. **Normal Giftcode**
- Giới hạn số lần dùng mỗi người
- Có thời hạn sử dụng
- Ví dụ: `WELCOME2024` - mỗi người dùng 1 lần, hết hạn sau 30 ngày

#### 2. **Random Giftcode** 
- Tạo nhiều code con từ 1 code chính
- Mỗi code con chỉ dùng 1 lần
- Ví dụ: Tạo `NEWYEAR` → Sinh ra 100 code con khác nhau

#### 3. **Limit Giftcode**
- Giới hạn tổng số lượt sử dụng
- Ai nhanh tay hơn
- Ví dụ: `FLASH100` - chỉ 100 người đầu tiên được dùng

### Phần thưởng hỗ trợ

- 💰 **Money** (Vault)
- 💎 **Points** (PlayerPoints) 
- ⭐ **Experience**
- 🎁 **Items** (kéo thả vào GUI)
- ⚡ **Commands** (thực thi lệnh tự động)

## ⚙️ Cấu hình nâng cao

### Settings chính
```yaml
Settings:
  IP-Check: true              # Kiểm tra IP
  GiftcodeFormat: "XXXX-XXXX-XXXX"  # Format code random
  CodeRandom: 10              # Số lượng code con được tạo
  RandomMaxUse: 1             # Số lần dùng tối đa code random
  AutoSave: 5                 # Tự động lưu (phút)
```

### Tùy chỉnh GUI
```yaml
Settings:
  Gui:
    Title: "&8Genz-Giftcode | Thiết lập phần thưởng"
    Items:
      Money:
        Material: GOLD_INGOT
        Name: "&f&lMoney: &a&l<money>"
```

### Tùy chỉnh thông báo
```yaml
Message:
  Prefix: "&8[&e&lGiftcode&8]"
  CodeReceived: "<prefix> &aChúc mừng, bạn đã nhận được quà Giftcode!"
  NoPermissions: "<prefix> &cBạn không có quyền làm điều này"
```

## 🔧 Permissions

| Permission | Mô tả | Default |
|------------|-------|---------|
| `dhgiftcode.*` | Tất cả quyền | op |
| `dhgiftcode.create` | Tạo giftcode | op |
| `dhgiftcode.edit` | Chỉnh sửa giftcode | op |
| `dhgiftcode.list` | Xem danh sách | op |
| `dhgiftcode.reload` | Reload plugin | op |
| `dhgiftcode.give` | Tặng code cho người khác | op |
| `dhgiftcode.use` | Sử dụng giftcode | true |
| `dhgiftcode.license` | Xem thông tin license | op |

## 🐛 Khắc phục sự cố

### Lỗi License
```
§c[Genz-Giftcode] License key chưa được cấu hình!
```
**Giải pháp**: Cập nhật license key trong config.yml

```
§c[Genz-Giftcode] ✗ License key không hợp lệ!
```
**Giải pháp**:
1. Kiểm tra kết nối internet
2. Xác nhận license key đúng
3. Liên hệ nhà phát triển nếu key không hoạt động

### Lỗi Folia
```
java.lang.IllegalStateException: Dispatching command async
```
**Giải pháp**: Plugin đã được cập nhật để tương thích với Folia

### GUI không hiện màu
**Giải pháp**: Plugin đã sử dụng legacy color format

## 🔄 Migration từ phiên bản cũ

1. **Backup dữ liệu**: Sao lưu thư mục `plugins/DH-Giftcode/`
2. **Thay plugin**: Thay file jar cũ bằng phiên bản mới
3. **Cấu hình license**: Thêm license key hợp lệ vào config.yml
4. **Khởi động**: Plugin sẽ tự động migrate config cũ

## 📞 Hỗ trợ

- **Website**: [minhtaz.dev](https://minhtaz.dev)
- **Email**: minhtaz.dev@gmail.com
- **Facebook**: [MinhTaz](https://www.facebook.com/minhtaz)
- **Discord**: [Genz Community](https://discord.gg/jndGk757Ms)

## 📋 Changelog

### v2.0.0
- ✅ Hỗ trợ Folia và Paper 1.21+
- ✅ Tích hợp Cryptolens Licensing
- ✅ Cải tiến GUI và màu sắc
- ✅ Sửa lỗi async command dispatch
- ✅ Offline licensing support
- ✅ Modern API với Adventure components

### v1.7.3 (Legacy)
- Phiên bản cũ chỉ hỗ trợ Spigot 1.16.5

---

**© 2024 MinhTaz - All Rights Reserved**