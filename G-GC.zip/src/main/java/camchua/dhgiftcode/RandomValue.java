package camchua.dhgiftcode;

import java.util.concurrent.ThreadLocalRandom;

/**
 * Utility class for handling random value ranges
 * Supports both fixed values and range-based random values
 */
public class RandomValue {

    private final double min;
    private final double max;
    private final double value;
    private final boolean isRandom;

    /**
     * Creates a RandomValue from a factor string
     * @param factor String in format "value" for fixed value or "min-max" for random range
     */
    public RandomValue(String factor) {
        if (Utils.isNullOrEmpty(factor)) {
            this.min = 0;
            this.max = 0;
            this.value = 0;
            this.isRandom = false;
            return;
        }

        if (factor.contains("-")) {
            String[] factors = factor.split("-", 2);
            if (factors.length == 2) {
                double tempMin = Utils.parseDouble(factors[0].trim(), 0);
                double tempMax = Utils.parseDouble(factors[1].trim(), 0);
                
                // Ensure min <= max
                if (tempMin > tempMax) {
                    this.min = tempMax;
                    this.max = tempMin;
                } else {
                    this.min = tempMin;
                    this.max = tempMax;
                }
                
                this.isRandom = this.min != this.max;
                if (this.isRandom) {
                    this.value = Utils.fixDouble(ThreadLocalRandom.current().nextDouble(this.min, this.max + 0.01)); // +0.01 to include max
                } else {
                    this.value = this.min;
                }
            } else {
                // Invalid format, default to 0
                this.min = 0;
                this.max = 0;
                this.value = 0;
                this.isRandom = false;
            }
        } else {
            double parsedValue = Utils.parseDouble(factor.trim(), 0);
            this.value = parsedValue;
            this.min = parsedValue;
            this.max = parsedValue;
            this.isRandom = false;
        }
    }

    /**
     * Creates a RandomValue with fixed min and max values
     * @param min minimum value
     * @param max maximum value
     */
    public RandomValue(double min, double max) {
        if (min > max) {
            this.min = max;
            this.max = min;
        } else {
            this.min = min;
            this.max = max;
        }
        
        this.isRandom = this.min != this.max;
        if (this.isRandom) {
            this.value = Utils.fixDouble(ThreadLocalRandom.current().nextDouble(this.min, this.max + 0.01));
        } else {
            this.value = this.min;
        }
    }

    /**
     * Creates a RandomValue with a fixed value
     * @param value the fixed value
     */
    public RandomValue(double value) {
        this.value = value;
        this.min = value;
        this.max = value;
        this.isRandom = false;
    }

    /**
     * Gets the calculated value
     * @return the value
     */
    public double getValue() {
        return value;
    }

    /**
     * Gets the minimum value
     * @return minimum value
     */
    public double getMin() {
        return min;
    }

    /**
     * Gets the maximum value
     * @return maximum value
     */
    public double getMax() {
        return max;
    }

    /**
     * Checks if this is a random value (min != max)
     * @return true if random, false if fixed
     */
    public boolean isRandom() {
        return isRandom;
    }

    /**
     * Gets the value as an integer
     * @return integer value
     */
    public int getIntValue() {
        return (int) Math.round(value);
    }

    /**
     * Generates a new random value within the same range
     * @return new RandomValue with same range but different random value
     */
    public RandomValue regenerate() {
        if (isRandom) {
            return new RandomValue(min, max);
        } else {
            return new RandomValue(value);
        }
    }

    /**
     * Checks if the value is positive
     * @return true if value > 0
     */
    public boolean isPositive() {
        return value > 0;
    }

    /**
     * Checks if the value is zero
     * @return true if value == 0
     */
    public boolean isZero() {
        return value == 0;
    }

    /**
     * Multiplies this value by a factor and returns a new RandomValue
     * @param factor the multiplication factor
     * @return new RandomValue with multiplied range
     */
    public RandomValue multiply(double factor) {
        if (isRandom) {
            return new RandomValue(min * factor, max * factor);
        } else {
            return new RandomValue(value * factor);
        }
    }

    /**
     * Adds a value to this range and returns a new RandomValue
     * @param addition the value to add
     * @return new RandomValue with added range
     */
    public RandomValue add(double addition) {
        if (isRandom) {
            return new RandomValue(min + addition, max + addition);
        } else {
            return new RandomValue(value + addition);
        }
    }

    @Override
    public String toString() {
        if (isRandom) {
            return Utils.fixDouble(min) + "-" + Utils.fixDouble(max);
        } else {
            return String.valueOf(Utils.fixDouble(value));
        }
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        
        RandomValue that = (RandomValue) obj;
        return Double.compare(that.min, min) == 0 &&
               Double.compare(that.max, max) == 0 &&
               Double.compare(that.value, value) == 0;
    }

    @Override
    public int hashCode() {
        return Double.valueOf(min).hashCode() * 31 + 
               Double.valueOf(max).hashCode() * 31 + 
               Double.valueOf(value).hashCode();
    }

    /**
     * Creates a RandomValue from an integer factor string
     * @param factor the factor string
     * @return RandomValue instance
     */
    public static RandomValue fromInt(String factor) {
        RandomValue rv = new RandomValue(factor);
        return new RandomValue(rv.getIntValue());
    }

    /**
     * Creates a percentage-based RandomValue (0.0 to 1.0)
     * @param factor factor string representing percentage
     * @return RandomValue with percentage values
     */
    public static RandomValue fromPercentage(String factor) {
        RandomValue rv = new RandomValue(factor);
        if (rv.isRandom()) {
            return new RandomValue(rv.getMin() / 100.0, rv.getMax() / 100.0);
        } else {
            return new RandomValue(rv.getValue() / 100.0);
        }
    }
}