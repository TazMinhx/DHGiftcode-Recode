package camchua.dhgiftcode;

import org.bukkit.Material;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import net.kyori.adventure.text.Component;

import java.util.ArrayList;
import java.util.List;

/**
 * Modern ItemBuilder utility class with Adventure API support
 */
public class ItemBuilder {
    
    private final ItemStack itemStack;
    private final ItemMeta itemMeta;
    
    private ItemBuilder(Material material) {
        this.itemStack = new ItemStack(material);
        this.itemMeta = itemStack.getItemMeta();
    }
    
    private ItemBuilder(Material material, int amount) {
        this.itemStack = new ItemStack(material, amount);
        this.itemMeta = itemStack.getItemMeta();
    }
    
    /**
     * Creates a new ItemBuilder instance
     * @param material the material
     * @return new ItemBuilder instance
     */
    public static ItemBuilder of(Material material) {
        return new ItemBuilder(material);
    }
    
    /**
     * Creates a new ItemBuilder instance with amount
     * @param material the material
     * @param amount the amount
     * @return new ItemBuilder instance
     */
    public static ItemBuilder of(Material material, int amount) {
        return new ItemBuilder(material, amount);
    }
    
    /**
     * Sets the display name using legacy format
     * @param name the display name
     * @return this ItemBuilder
     */
    public ItemBuilder name(String name) {
        if (itemMeta != null && name != null) {
            itemMeta.displayName(Utils.parseComponent(name));
        }
        return this;
    }
    
    /**
     * Sets the display name using Component
     * @param name the display name component
     * @return this ItemBuilder
     */
    public ItemBuilder name(Component name) {
        if (itemMeta != null && name != null) {
            itemMeta.displayName(name);
        }
        return this;
    }
    
    /**
     * Sets the lore using legacy format strings
     * @param lore the lore lines
     * @return this ItemBuilder
     */
    public ItemBuilder lore(List<String> lore) {
        if (itemMeta != null && lore != null) {
            List<Component> componentLore = new ArrayList<>();
            for (String line : lore) {
                componentLore.add(Utils.parseComponent(line));
            }
            itemMeta.lore(componentLore);
        }
        return this;
    }
    
    /**
     * Sets the lore using Component list
     * @param lore the lore components
     * @return this ItemBuilder
     */
    public ItemBuilder loreComponents(List<Component> lore) {
        if (itemMeta != null && lore != null) {
            itemMeta.lore(lore);
        }
        return this;
    }
    
    /**
     * Adds a single lore line
     * @param line the lore line
     * @return this ItemBuilder
     */
    public ItemBuilder addLore(String line) {
        if (itemMeta != null && line != null) {
            List<Component> currentLore = itemMeta.lore();
            if (currentLore == null) {
                currentLore = new ArrayList<>();
            }
            currentLore.add(Utils.parseComponent(line));
            itemMeta.lore(currentLore);
        }
        return this;
    }
    
    /**
     * Sets the amount
     * @param amount the amount
     * @return this ItemBuilder
     */
    public ItemBuilder amount(int amount) {
        itemStack.setAmount(Math.max(1, Math.min(64, amount)));
        return this;
    }
    
    /**
     * Builds and returns the ItemStack
     * @return the built ItemStack
     */
    public ItemStack build() {
        if (itemMeta != null) {
            itemStack.setItemMeta(itemMeta);
        }
        return itemStack;
    }
    
    // Static utility methods for backward compatibility
    
    /**
     * Creates an ItemStack with legacy support
     * @param mat the material
     * @return ItemStack
     */
    public static ItemStack create(Material mat) {
        return new ItemStack(mat);
    }
    
    /**
     * Creates an ItemStack with amount
     * @param mat the material
     * @param amount the amount
     * @return ItemStack
     */
    public static ItemStack create(Material mat, int amount) {
        return new ItemStack(mat, amount);
    }
    
    /**
     * Creates an ItemStack with amount and legacy data (ignored in modern versions)
     * @param mat the material
     * @param amount the amount
     * @param data the data value (ignored)
     * @return ItemStack
     */
    public static ItemStack create(Material mat, int amount, int data) {
        return new ItemStack(mat, amount);
    }
    
    /**
     * Creates an ItemStack with amount, data, and display name
     * @param mat the material
     * @param amount the amount
     * @param data the data value (ignored)
     * @param displayname the display name
     * @return ItemStack
     */
    public static ItemStack create(Material mat, int amount, int data, String displayname) {
        return ItemBuilder.of(mat, amount)
                .name(displayname)
                .build();
    }
    
    /**
     * Creates an ItemStack with amount, data, display name, and lore
     * @param mat the material
     * @param amount the amount
     * @param data the data value (ignored)
     * @param displayname the display name
     * @param lore the lore lines
     * @return ItemStack
     */
    public static ItemStack create(Material mat, int amount, int data, String displayname, List<String> lore) {
        return ItemBuilder.of(mat, amount)
                .name(displayname)
                .lore(lore)
                .build();
    }
    
    /**
     * Creates an ItemStack with amount, data, display name, lore, and replacements
     * @param mat the material
     * @param amount the amount
     * @param data the data value (ignored)
     * @param displayname the display name
     * @param lore the lore lines
     * @param lorereplace replacement strings in format "from:to"
     * @return ItemStack
     */
    public static ItemStack create(Material mat, int amount, int data, String displayname, 
                                 List<String> lore, List<String> lorereplace) {
        List<String> processedLore = new ArrayList<>();
        
        if (lore != null && lorereplace != null) {
            for (String line : lore) {
                String processedLine = line;
                for (String replacement : lorereplace) {
                    if (replacement.contains(":")) {
                        String[] parts = replacement.split(":", 2);
                        if (parts.length == 2) {
                            processedLine = processedLine.replace(parts[0], parts[1]);
                        }
                    }
                }
                processedLore.add(processedLine);
            }
        } else if (lore != null) {
            processedLore.addAll(lore);
        }
        
        return ItemBuilder.of(mat, amount)
                .name(displayname)
                .lore(processedLore)
                .build();
    }
}