package camchua.dhgiftcode;

import org.bukkit.plugin.Plugin;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.logging.Level;

/**
 * Simple Key Checker System for DH-Giftcode
 * Checks license key against GitHub raw content
 */
public class SimpleKeyChecker {
    
    private static final String KEY_CHECK_URL = "https://raw.githubusercontent.com/TazMinhx/KeyDiHoa/refs/heads/main/Gaya.yml";
    private final Plugin plugin;
    private boolean isValidated = false;
    
    public SimpleKeyChecker(Plugin plugin) {
        this.plugin = plugin;
    }
    
    /**
     * Validates license key by checking against GitHub
     * @param userKey The license key from config
     * @return true if key is valid
     */
    public boolean validateKey(String userKey) {
        try {
            plugin.getLogger().info("§7Đang kiểm tra license key...");

            if (Utils.isNullOrEmpty(userKey)) {
                plugin.getLogger().severe("§cLicense key không được để trống!");
                return false;
            }

            // Fetch valid key from GitHub
            String validKey = fetchValidKeyFromGitHub();

            if (validKey == null) {
                plugin.getLogger().severe("§cKhông thể kết nối đến server xác thực!");
                return false;
            }

            // Compare keys
            if (userKey.trim().equals(validKey.trim())) {
                isValidated = true;
                plugin.getLogger().info("§a✓ License key hợp lệ - Plugin sẵn sàng!");
                return true;
            } else {
                plugin.getLogger().severe("§c✗ License key không hợp lệ!");
                plugin.getLogger().severe("§cPlugin sẽ bị vô hiệu hóa.");
                return false;
            }

        } catch (Exception e) {
            plugin.getLogger().log(Level.SEVERE, "§cLỗi khi kiểm tra license: " + e.getMessage());
            return false;
        }
    }
    
    /**
     * Fetches valid key from GitHub raw URL
     * @return The valid key string, or null if failed
     */
    private String fetchValidKeyFromGitHub() {
        try {
            URL url = new URL(KEY_CHECK_URL);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();

            // Set connection properties
            connection.setRequestMethod("GET");
            connection.setConnectTimeout(5000);
            connection.setReadTimeout(10000);
            connection.setRequestProperty("User-Agent", "Genz-Giftcode/3.0.0");

            // Check response code
            int responseCode = connection.getResponseCode();
            if (responseCode != 200) {
                plugin.getLogger().warning("§eServer trả về code: " + responseCode);
                return null;
            }

            // Read response
            BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
            StringBuilder response = new StringBuilder();
            String line;

            while ((line = reader.readLine()) != null) {
                response.append(line).append("\n");
            }

            reader.close();
            connection.disconnect();

            return response.toString().trim();

        } catch (Exception e) {
            plugin.getLogger().log(Level.WARNING, "§eKhông thể kết nối server: " + e.getMessage());
            return null;
        }
    }
    
    /**
     * Checks if license is currently valid
     * @return true if validated
     */
    public boolean isValid() {
        return isValidated;
    }
    
    /**
     * Gets license information
     * @return License info string
     */
    public String getLicenseInfo() {
        if (!isValidated) {
            return "§cLicense chưa được xác thực";
        }

        return "§a✓ License hợp lệ - Genz-Giftcode v3.0.0";
    }
    
    /**
     * Re-validates the key (useful for reload)
     * @param userKey The key to validate
     * @return true if still valid
     */
    public boolean revalidate(String userKey) {
        isValidated = false;
        return validateKey(userKey);
    }
    
    /**
     * Deactivation method (for compatibility)
     * @return always true for simple system
     */
    public boolean deactivate() {
        isValidated = false;
        plugin.getLogger().info("§aLicense đã được hủy kích hoạt");
        return true;
    }
    
    /**
     * Gets the validation URL for reference
     * @return The GenzKeyCheck URL used for validation
     */
    public String getValidationUrl() {
        return KEY_CHECK_URL;
    }
}