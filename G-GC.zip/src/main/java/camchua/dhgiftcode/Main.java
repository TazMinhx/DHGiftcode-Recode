package camchua.dhgiftcode;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.audience.Audience;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.Statistic;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.player.AsyncPlayerChatEvent;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.PluginManager;
import org.bukkit.plugin.java.JavaPlugin;

// Folia support
import io.papermc.paper.threadedregions.scheduler.ScheduledTask;
import io.papermc.paper.threadedregions.scheduler.EntityScheduler;
import io.papermc.paper.threadedregions.scheduler.GlobalRegionScheduler;
import io.papermc.paper.threadedregions.scheduler.RegionScheduler;

import java.io.File;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;

/**
 * Genz-Giftcode Main Plugin Class
 * Rewritten with Folia support and modern Paper API
 *
 * @author MinhTaz
 * @version 3.0.0
 */
public class Main extends JavaPlugin implements Listener {
    
    // Configuration files
    private File configFile;
    private File giftcodeFile;
    private FileConfiguration config;
    private FileConfiguration giftcode;
    
    // License management - Simple GitHub Key Validation
    private SimpleKeyChecker keyChecker;
    private boolean isLicensed = false;
    
    // Plugin state
    private String giftcodeFormat = "XXXX-XXXX-XXXX";
    private final Map<String, String> editSessions = new HashMap<>();
    private final int[] itemSlots = {10, 11, 12, 13, 14, 15, 16, 19, 20, 21, 22, 23, 24, 25, 28, 29, 30, 31, 32, 33, 34, 37, 38, 39, 40, 41, 42, 43};
    
    // Scheduled tasks
    private ScheduledTask autoSaveTask;
    
    @Override
    public void onEnable() {
        // Initialize plugin
        getLogger().info("[Genz-Giftcode] ✓ Plugin loaded successfully! Version: 3.0.0 | Author: MinhTaz");
        getLogger().info("[Genz-Giftcode] Support: Folia + Paper 1.20.4+ | Running on: " + (isFoliaServer() ? "Folia" : "Paper/Spigot"));
        
        // Load configurations
        if (!loadConfigurations()) {
            getLogger().severe("Failed to load configurations! Disabling plugin.");
            getServer().getPluginManager().disablePlugin(this);
            return;
        }
        
        // Initialize license
        keyChecker = new SimpleKeyChecker(this);
        String licenseKey = config.getString("license", "");
        
        if (Utils.isNullOrEmpty(licenseKey) || licenseKey.equals("TEST-LICENSE-KEY-FOR-TESTING")) {
            getLogger().severe("[Genz-Giftcode] License key chưa được cấu hình!");
            getLogger().severe("Vui lòng cấu hình license key trong config.yml");
            getLogger().severe("Liên hệ MinhTaz để nhận key hợp lệ");
            getServer().getPluginManager().disablePlugin(this);
            return;
        }
        
        // Validate license
        if (!keyChecker.validateKey(licenseKey)) {
            getLogger().severe("[Genz-Giftcode] License validation failed! Disabling plugin.");
            getServer().getPluginManager().disablePlugin(this);
            return;
        }

        isLicensed = true;
        getLogger().info("[Genz-Giftcode] Plugin licensed and ready!");
        
        // Load plugin settings
        loadSettings();
        
        // Register events
        getServer().getPluginManager().registerEvents(this, this);
        
        // Start auto-save task
        startAutoSaveTask();
        
        getLogger().info("[Genz-Giftcode] Plugin enabled successfully!");
    }
    
    @Override
    public void onDisable() {
        // Stop tasks
        if (autoSaveTask != null && !autoSaveTask.isCancelled()) {
            autoSaveTask.cancel();
        }

        // Deactivate license
        if (keyChecker != null) {
            keyChecker.deactivate();
        }

        // Save data
        saveConfigurations();

        getLogger().info("[Genz-Giftcode] Plugin disabled.");
    }
    
    /**
     * Checks if the server is running on Folia
     */
    private boolean isFoliaServer() {
        try {
            Class.forName("io.papermc.paper.threadedregions.scheduler.GlobalRegionScheduler");
            return true;
        } catch (ClassNotFoundException e) {
            return false;
        }
    }
    
    /**
     * Loads configuration files
     */
    private boolean loadConfigurations() {
        try {
            // Create data folder if not exists
            if (!getDataFolder().exists()) {
                getDataFolder().mkdirs();
            }
            
            // Initialize config files
            configFile = new File(getDataFolder(), "config.yml");
            giftcodeFile = new File(getDataFolder(), "giftcode.yml");
            
            // Save default config if not exists
            if (!configFile.exists()) {
                saveResource("config.yml", false);
            }
            if (!giftcodeFile.exists()) {
                saveResource("giftcode.yml", false);
            }
            
            // Load configurations
            config = YamlConfiguration.loadConfiguration(configFile);
            giftcode = YamlConfiguration.loadConfiguration(giftcodeFile);
            
            return true;
        } catch (Exception e) {
            getLogger().log(Level.SEVERE, "Error loading configurations", e);
            return false;
        }
    }
    
    /**
     * Saves configuration files
     */
    private void saveConfigurations() {
        try {
            if (config != null && configFile != null) {
                config.save(configFile);
            }
            if (giftcode != null && giftcodeFile != null) {
                giftcode.save(giftcodeFile);
            }
        } catch (Exception e) {
            getLogger().log(Level.WARNING, "Error saving configurations", e);
        }
    }
    
    /**
     * Loads plugin settings from config
     */
    private void loadSettings() {
        giftcodeFormat = config.getString("Settings.GiftcodeFormat", "XXXX-XXXX-XXXX");
    }
    
    /**
     * Starts the auto-save task using appropriate scheduler
     */
    private void startAutoSaveTask() {
        int autoSaveMinutes = config.getInt("Settings.AutoSave", 5);
        if (autoSaveMinutes <= 0) return;
        
        long interval = autoSaveMinutes * 60L * 20L; // Convert to ticks
        
        if (isFoliaServer()) {
            // Use Folia's GlobalRegionScheduler
            autoSaveTask = Bukkit.getGlobalRegionScheduler().runAtFixedRate(this, (task) -> {
                saveConfigurations();
                if (config.getBoolean("Settings.Debug", false)) {
                    getLogger().info("§7Auto-saved configurations");
                }
            }, interval, interval);
        } else {
            // Use legacy BukkitScheduler
            Bukkit.getScheduler().runTaskTimerAsynchronously(this, () -> {
                saveConfigurations();
                if (config.getBoolean("Settings.Debug", false)) {
                    getLogger().info("Auto-saved configurations");
                }
            }, interval, interval);
        }
    }
    
    /**
     * Schedules a task for later execution
     */
    private void scheduleTask(Runnable task, long delayTicks) {
        if (isFoliaServer()) {
            Bukkit.getGlobalRegionScheduler().runDelayed(this, (scheduledTask) -> task.run(), delayTicks);
        } else {
            Bukkit.getScheduler().runTaskLater(this, task, delayTicks);
        }
    }
    
    /**
     * Schedules a task for a specific player
     */
    private void schedulePlayerTask(Player player, Runnable task, long delayTicks) {
        if (isFoliaServer()) {
            player.getScheduler().runDelayed(this, (scheduledTask) -> task.run(), null, delayTicks);
        } else {
            Bukkit.getScheduler().runTaskLater(this, task, delayTicks);
        }
    }
    
    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!isLicensed) {
            sender.sendMessage(Utils.colorize(getMessage("LicenseInvalid")));
            return true;
        }
        
        if (args.length == 0) {
            return handleHelpCommand(sender);
        }
        
        String subCommand = args[0].toLowerCase();
        
        switch (subCommand) {
            case "create":
                return handleCreateCommand(sender, args);
            case "edit":
                return handleEditCommand(sender, args);
            case "list":
                return handleListCommand(sender);
            case "reload":
                return handleReloadCommand(sender);
            case "help":
                return handleHelpCommand(sender);
            default:
                return handleUseCommand(sender, args);
        }
    }
    
    /**
     * Handles the help command
     */
    private boolean handleHelpCommand(CommandSender sender) {
        if (!sender.hasPermission("dhgiftcode.help")) {
            sender.sendMessage(Utils.colorize(getMessage("NoPermissions")));
            return true;
        }
        
        List<String> helpMessages = config.getStringList("Message.Help");
        for (String message : helpMessages) {
            sender.sendMessage(Utils.colorize(message));
        }
        return true;
    }
    
    /**
     * Handles the create command
     */
    private boolean handleCreateCommand(CommandSender sender, String[] args) {
        if (!sender.hasPermission("dhgiftcode.create")) {
            sender.sendMessage(Utils.colorize(getMessage("NoPermissions")));
            return true;
        }
        
        if (!(sender instanceof Player)) {
            sender.sendMessage(Utils.colorize(getMessage("PlayerOnly")));
            return true;
        }
        
        if (args.length < 2) {
            sender.sendMessage(Utils.colorize("§cUsage: /giftcode create <code> [type]"));
            return true;
        }
        
        Player player = (Player) sender;
        String code = args[1];
        
        if (giftcode.contains(code)) {
            sender.sendMessage(Utils.colorize(getMessage("CodeExist")));
            return true;
        }
        
        String type = args.length >= 3 ? args[2].toLowerCase() : "normal";
        
        // Create giftcode
        giftcode.set(code + ".Type", type);
        giftcode.set(code + ".RequireOnline", 24);
        
        switch (type) {
            case "random":
                // Random type setup
                break;
            case "limit":
                // Limit type setup
                break;
            default:
                // Normal type setup
                giftcode.set(code + ".Limit", 1);
                break;
        }
        
        saveConfigurations();
        
        // Open GUI for editing
        editSessions.put(player.getName(), code + ":none");
        schedulePlayerTask(player, () -> openGiftcodeGUI(player, code), 1L);
        
        return true;
    }
    
    /**
     * Handles the edit command
     */
    private boolean handleEditCommand(CommandSender sender, String[] args) {
        if (!sender.hasPermission("dhgiftcode.edit")) {
            sender.sendMessage(Utils.colorize(getMessage("NoPermissions")));
            return true;
        }
        
        if (!(sender instanceof Player)) {
            sender.sendMessage(Utils.colorize(getMessage("PlayerOnly")));
            return true;
        }
        
        if (args.length < 2) {
            sender.sendMessage(Utils.colorize("§cUsage: /giftcode edit <code>"));
            return true;
        }
        
        Player player = (Player) sender;
        String code = args[1];
        
        if (!giftcode.contains(code)) {
            sender.sendMessage(Utils.colorize(getMessage("CodeNotExist")));
            return true;
        }
        
        editSessions.put(player.getName(), code + ":none");
        schedulePlayerTask(player, () -> openGiftcodeGUI(player, code), 1L);
        
        return true;
    }
    
    /**
     * Handles the list command
     */
    private boolean handleListCommand(CommandSender sender) {
        if (!sender.hasPermission("dhgiftcode.list")) {
            sender.sendMessage(Utils.colorize(getMessage("NoPermissions")));
            return true;
        }
        
        Set<String> codes = giftcode.getKeys(false);
        if (codes.isEmpty()) {
            sender.sendMessage(Utils.colorize("&7Chưa có giftcode nào được tạo"));
            return true;
        }
        
        StringBuilder codeList = new StringBuilder();
        for (String code : codes) {
            if (!code.equals("version")) {
                codeList.append(" ").append(code);
            }
        }
        
        String message = getMessage("CodeList").replace("<code>", codeList.toString());
        sender.sendMessage(Utils.colorize(message));
        
        return true;
    }
    
    /**
     * Handles the reload command
     */
    private boolean handleReloadCommand(CommandSender sender) {
        if (!sender.hasPermission("dhgiftcode.reload")) {
            sender.sendMessage(Utils.colorize(getMessage("NoPermissions")));
            return true;
        }
        
        try {
            // Reload configurations
            config = YamlConfiguration.loadConfiguration(configFile);
            giftcode = YamlConfiguration.loadConfiguration(giftcodeFile);
            
            // Reload settings
            loadSettings();
            
            sender.sendMessage(Utils.colorize(getMessage("Reloaded")));
        } catch (Exception e) {
            sender.sendMessage(Utils.colorize(getMessage("ReloadFailed")));
            getLogger().log(Level.SEVERE, "Error during reload", e);
        }
        
        return true;
    }
    
    
    /**
     * Handles using a giftcode
     */
    private boolean handleUseCommand(CommandSender sender, String[] args) {
        String code = args[0];
        Player targetPlayer = null;
        
        // Determine target player
        if (args.length >= 2) {
            if (!sender.hasPermission("dhgiftcode.give")) {
                sender.sendMessage(Utils.colorize(getMessage("NoPermissions")));
                return true;
            }
            
            targetPlayer = Bukkit.getPlayer(args[1]);
            if (targetPlayer == null || !targetPlayer.isOnline()) {
                sender.sendMessage(Utils.colorize(getMessage("NotOnline")));
                return true;
            }
        } else if (sender instanceof Player) {
            targetPlayer = (Player) sender;
        } else {
            sender.sendMessage(Utils.colorize(getMessage("PlayerOnly")));
            return true;
        }
        
        // Check permission
        if (!targetPlayer.hasPermission("dhgiftcode.use")) {
            sender.sendMessage(Utils.colorize(getMessage("NoPermissions")));
            return true;
        }
        
        // Process giftcode usage
        return processGiftcodeUsage(targetPlayer, code, sender);
    }
    
    /**
     * Processes giftcode usage logic
     */
    private boolean processGiftcodeUsage(Player player, String code, CommandSender sender) {
        // Check if code exists and process different types
        for (String giftcodeKey : giftcode.getKeys(false)) {
            if (giftcodeKey.equals("version")) continue;
            
            String type = giftcode.getString(giftcodeKey + ".Type", "normal");
            
            if (type.equals("normal") && giftcodeKey.equals(code)) {
                return processNormalGiftcode(player, code, sender);
            } else if (type.equals("random")) {
                List<String> codes = giftcode.getStringList(giftcodeKey + ".Giftcode");
                if (codes.contains(code)) {
                    return processRandomGiftcode(player, code, giftcodeKey, sender);
                }
            } else if (type.equals("limit") && giftcodeKey.equals(code)) {
                return processLimitGiftcode(player, code, sender);
            }
        }
        
        // Code not found
        player.sendMessage(Utils.colorize(getMessage("CodeNotFound")));
        return true;
    }
    
    /**
     * Processes normal giftcode usage
     */
    private boolean processNormalGiftcode(Player player, String code, CommandSender sender) {
        // Check expiry
        String expiredStr = giftcode.getString(code + ".Expired");
        if (expiredStr != null) {
            SimpleDateFormat sdf = new SimpleDateFormat("HH:mm:ss dd-MM-yyyy");
            try {
                Date expiredDate = sdf.parse(expiredStr);
                if (new Date().after(expiredDate)) {
                    player.sendMessage(Utils.colorize("&cMã code này đã hết hạn"));
                    return true;
                }
            } catch (ParseException e) {
                getLogger().warning("Invalid date format for code: " + code);
            }
        }
        
        // Check online time requirement
        int requiredOnline = giftcode.getInt(code + ".RequireOnline", 24);
        if (!checkOnlineTimeRequirement(player, requiredOnline)) {
            String message = getMessage("RequireOnline").replace("<require>", String.valueOf(requiredOnline));
            player.sendMessage(Utils.colorize(message));
            return true;
        }
        
        // Check usage limit
        int limit = giftcode.getInt(code + ".Limit", 1);
        List<String> usedPlayers = giftcode.getStringList(code + ".Used");
        int playerUsageCount = countPlayerUsage(usedPlayers, player.getName());
        
        if (playerUsageCount >= limit) {
            player.sendMessage(Utils.colorize(getMessage("AlreadyUseCode")));
            return true;
        }
        
        // Check IP restriction
        if (config.getBoolean("Settings.IP-Check", true)) {
            String playerIP = player.getAddress().getAddress().getHostAddress();
            List<String> usedIPs = giftcode.getStringList(code + ".IpUsed");
            if (usedIPs.contains(playerIP) && playerUsageCount == 0) {
                player.sendMessage(Utils.colorize(getMessage("CodeIpUsed")));
                return true;
            }
        }
        
        // Give rewards
        giveRewards(player, code);
        
        // Update usage
        usedPlayers.add(player.getName());
        giftcode.set(code + ".Used", usedPlayers);
        giftcode.set(code + ".Use", giftcode.getInt(code + ".Use", 0) + 1);
        
        if (config.getBoolean("Settings.IP-Check", true)) {
            String playerIP = player.getAddress().getAddress().getHostAddress();
            List<String> usedIPs = giftcode.getStringList(code + ".IpUsed");
            usedIPs.add(playerIP);
            giftcode.set(code + ".IpUsed", usedIPs);
        }
        
        saveConfigurations();
        
        // Send messages
        player.sendMessage(Utils.colorize(getMessage("CodeReceived")));
        
        String broadcastMessage = config.getString("Message.PlayerCodeReceived", "");
        if (!broadcastMessage.isEmpty()) {
            Component message = Utils.parseComponent(broadcastMessage.replace("<player>", player.getName()));
            Bukkit.broadcast(message);
        }
        
        return true;
    }
    
    /**
     * Processes random giftcode usage
     */
    private boolean processRandomGiftcode(Player player, String code, String mainCode, CommandSender sender) {
        // Implementation similar to normal but with random logic
        // This is a simplified version - you can expand based on needs
        
        List<String> usedPlayers = giftcode.getStringList(mainCode + ".Used");
        int maxUse = config.getInt("Settings.RandomMaxUse", 1);
        int playerUsage = countPlayerUsage(usedPlayers, player.getName());
        
        if (maxUse > 0 && playerUsage >= maxUse) {
            player.sendMessage(Utils.colorize(getMessage("AlreadyUseCodeRandom")));
            return true;
        }
        
        // Give rewards and remove code from available list
        giveRandomRewards(player, mainCode);
        
        // Update data
        usedPlayers.add(player.getName());
        giftcode.set(mainCode + ".Used", usedPlayers);
        
        List<String> availableCodes = giftcode.getStringList(mainCode + ".Giftcode");
        availableCodes.remove(code);
        giftcode.set(mainCode + ".Giftcode", availableCodes);
        
        saveConfigurations();
        
        player.sendMessage(Utils.colorize(getMessage("CodeReceived")));
        return true;
    }
    
    /**
     * Processes limit giftcode usage
     */
    private boolean processLimitGiftcode(Player player, String code, CommandSender sender) {
        // Check if player already used
        List<String> usedPlayers = giftcode.getStringList(code + ".Used");
        if (usedPlayers.contains(player.getName())) {
            player.sendMessage(Utils.colorize(getMessage("AlreadyUseCode")));
            return true;
        }
        
        // Check total usage limit
        int currentUse = giftcode.getInt(code + ".Use", 0);
        int maxUse = giftcode.getInt(code + ".MaxUse", 1);
        
        if (currentUse >= maxUse) {
            player.sendMessage(Utils.colorize(getMessage("CodeMaxUse")));
            return true;
        }
        
        // Give rewards
        giveRewards(player, code);
        
        // Update usage
        usedPlayers.add(player.getName());
        giftcode.set(code + ".Used", usedPlayers);
        giftcode.set(code + ".Use", currentUse + 1);
        
        saveConfigurations();
        
        player.sendMessage(Utils.colorize(getMessage("CodeReceived")));
        return true;
    }
    
    /**
     * Checks if player meets online time requirement
     */
    private boolean checkOnlineTimeRequirement(Player player, int requiredHours) {
        if (requiredHours <= 0) return true;
        
        try {
            // Try modern statistic first
            int playTime = 0;
            try {
                // For 1.13+
                playTime = player.getStatistic(Statistic.valueOf("PLAY_ONE_TICK")) / 20;
            } catch (IllegalArgumentException e1) {
                try {
                    // For older versions
                    playTime = player.getStatistic(Statistic.valueOf("PLAY_ONE_MINUTE")) * 60;
                } catch (IllegalArgumentException e2) {
                    // Very old versions - just return true
                    getLogger().warning("Could not check play time for player: " + player.getName() + " (unsupported version)");
                    return true;
                }
            }
            
            int requiredSeconds = requiredHours * 3600;
            return playTime >= requiredSeconds;
        } catch (Exception e) {
            getLogger().warning("Could not check play time for player: " + player.getName());
            return false; // Prevent if we can't check
        }
    }
    
    /**
     * Counts how many times a player has used a giftcode
     */
    private int countPlayerUsage(List<String> usedList, String playerName) {
        return (int) usedList.stream().filter(name -> name.equals(playerName)).count();
    }
    
    /**
     * Gives rewards to player for normal/limit giftcodes
     */
    private void giveRewards(Player player, String code) {
        // Give money
        double money = giftcode.getDouble(code + ".Money", 0);
        if (money > 0) {
            scheduleTask(() -> {
                Bukkit.dispatchCommand(Bukkit.getConsoleSender(), "eco give " + player.getName() + " " + money);
            }, 1L);
        }
        
        // Give points
        int points = giftcode.getInt(code + ".Points", 0);
        if (points > 0) {
            scheduleTask(() -> {
                Bukkit.dispatchCommand(Bukkit.getConsoleSender(), "points give " + player.getName() + " " + points);
            }, 1L);
        }
        
        // Give experience
        int exp = giftcode.getInt(code + ".Exp", 0);
        if (exp > 0) {
            player.giveExp(exp);
        }
        
        // Give items
        if (giftcode.contains(code + ".Item")) {
            for (String itemKey : giftcode.getConfigurationSection(code + ".Item").getKeys(false)) {
                ItemStack item = giftcode.getItemStack(code + ".Item." + itemKey);
                if (item != null) {
                    player.getInventory().addItem(item);
                }
            }
        }
        
        // Execute commands
        List<String> commands = giftcode.getStringList(code + ".Command");
        for (String command : commands) {
            String processedCommand = command.replace("<player>", player.getName());
            scheduleTask(() -> {
                Bukkit.dispatchCommand(Bukkit.getConsoleSender(), processedCommand);
            }, 1L);
        }
    }
    
    /**
     * Gives random rewards to player
     */
    private void giveRandomRewards(Player player, String code) {
        // Similar to giveRewards but with RandomValue processing
        
        // Money
        String moneyStr = giftcode.getString(code + ".Money", "0");
        RandomValue money = new RandomValue(moneyStr);
        if (money.isPositive()) {
            Bukkit.dispatchCommand(Bukkit.getConsoleSender(), "eco give " + player.getName() + " " + money.getValue());
        }
        
        // Points
        String pointsStr = giftcode.getString(code + ".Points", "0");
        RandomValue points = new RandomValue(pointsStr);
        if (points.isPositive()) {
            Bukkit.dispatchCommand(Bukkit.getConsoleSender(), "points give " + player.getName() + " " + points.getIntValue());
        }
        
        // Experience
        String expStr = giftcode.getString(code + ".Exp", "0");
        RandomValue exp = new RandomValue(expStr);
        if (exp.isPositive()) {
            player.giveExp(exp.getIntValue());
        }
        
        // Random items
        if (giftcode.contains(code + ".Item")) {
            String limitStr = giftcode.getString(code + ".Limit", "0");
            RandomValue limit = new RandomValue(limitStr);
            
            Set<String> itemKeys = giftcode.getConfigurationSection(code + ".Item").getKeys(false);
            List<String> keyList = new ArrayList<>(itemKeys);
            
            if (limit.getValue() <= 0) {
                // Give all items
                for (String itemKey : keyList) {
                    ItemStack item = giftcode.getItemStack(code + ".Item." + itemKey);
                    if (item != null) {
                        player.getInventory().addItem(item.clone());
                    }
                }
            } else {
                // Give random selection
                Collections.shuffle(keyList);
                int itemsToGive = Math.min(keyList.size(), limit.getIntValue());
                
                for (int i = 0; i < itemsToGive; i++) {
                    ItemStack item = giftcode.getItemStack(code + ".Item." + keyList.get(i));
                    if (item != null) {
                        player.getInventory().addItem(item.clone());
                    }
                }
            }
        }
        
        // Execute commands
        List<String> commands = giftcode.getStringList(code + ".Command");
        for (String command : commands) {
            String processedCommand = command.replace("<player>", player.getName());
            scheduleTask(() -> {
                Bukkit.dispatchCommand(Bukkit.getConsoleSender(), processedCommand);
            }, 1L);
        }
    }
    
    /**
     * Opens the giftcode editing GUI
     */
    private void openGiftcodeGUI(Player player, String code) {
        String guiTitle = Utils.colorize(config.getString("Settings.Gui.Title", "&8Genz-Giftcode | Thiết lập phần thưởng"));
        Inventory inventory = Bukkit.createInventory(null, 54, guiTitle);
        
        // Load current values
        RandomValue money = new RandomValue(giftcode.getString(code + ".Money", "0"));
        RandomValue points = new RandomValue(giftcode.getString(code + ".Points", "0"));
        RandomValue exp = new RandomValue(giftcode.getString(code + ".Exp", "0"));
        RandomValue limit = new RandomValue(giftcode.getString(code + ".Limit", "0"));
        int requireOnline = giftcode.getInt(code + ".RequireOnline", 24);
        
        // Create GUI items with proper colors
        ItemStack fillerItem = ItemBuilder.create(Material.GRAY_STAINED_GLASS_PANE, 1, 0, "&r");
        ItemStack cancelItem = ItemBuilder.create(Material.RED_STAINED_GLASS_PANE, 1, 0, "&c&lXóa");
        ItemStack saveItem = ItemBuilder.create(Material.LIME_STAINED_GLASS_PANE, 1, 0, "&a&lLưu");
        
        // Money item
        Material moneyMaterial = Material.valueOf(config.getString("Settings.Gui.Items.Money.Material", "GOLD_INGOT"));
        String moneyName = Utils.colorize(config.getString("Settings.Gui.Items.Money.Name", "&f&lMoney: &a&l<money>")
                .replace("<money>", money.toString()));
        List<String> moneyLore = config.getStringList("Settings.Gui.Items.Money.Lore");
        ItemStack moneyItem = ItemBuilder.create(moneyMaterial, 1, 0, moneyName, moneyLore);
        
        // Points item
        Material pointsMaterial = Material.valueOf(config.getString("Settings.Gui.Items.Points.Material", "EMERALD"));
        String pointsName = Utils.colorize(config.getString("Settings.Gui.Items.Points.Name", "&f&lPoint: &6&l<points> ⛁")
                .replace("<points>", points.toString()));
        List<String> pointsLore = config.getStringList("Settings.Gui.Items.Points.Lore");
        ItemStack pointsItem = ItemBuilder.create(pointsMaterial, 1, 0, pointsName, pointsLore);
        
        // Exp item
        Material expMaterial = Material.valueOf(config.getString("Settings.Gui.Items.Exp.Material", "EXPERIENCE_BOTTLE"));
        String expName = Utils.colorize(config.getString("Settings.Gui.Items.Exp.Name", "&f&lExp: &d&l<exp>")
                .replace("<exp>", exp.toString()));
        List<String> expLore = config.getStringList("Settings.Gui.Items.Exp.Lore");
        ItemStack expItem = ItemBuilder.create(expMaterial, 1, 0, expName, expLore);
        
        // Require Online item
        Material onlineMaterial = Material.valueOf(config.getString("Settings.Gui.Items.RequireOnline.Material", "CLOCK"));
        String onlineName = Utils.colorize(config.getString("Settings.Gui.Items.RequireOnline.Name", "&f&lRequire Online: &b&l<online>h")
                .replace("<online>", String.valueOf(requireOnline)));
        List<String> onlineLore = config.getStringList("Settings.Gui.Items.RequireOnline.Lore");
        ItemStack onlineItem = ItemBuilder.create(onlineMaterial, 1, 0, onlineName, onlineLore);
        
        // Fill borders with glass panes (include slot 9 and 10)
        for (int i = 0; i <= 9; i++) {
            inventory.setItem(i, fillerItem);
        }
        inventory.setItem(17, fillerItem);
        inventory.setItem(18, fillerItem);
        inventory.setItem(26, fillerItem);
        inventory.setItem(27, fillerItem);
        inventory.setItem(35, fillerItem);
        inventory.setItem(36, fillerItem);
        inventory.setItem(44, fillerItem);
        inventory.setItem(48, fillerItem);
        inventory.setItem(50, fillerItem);
        
        // Set action items
        inventory.setItem(46, onlineItem);
        inventory.setItem(47, moneyItem);
        inventory.setItem(49, pointsItem);
        inventory.setItem(51, expItem);
        inventory.setItem(52, createLimitItem(code, limit));
        
        inventory.setItem(45, cancelItem);
        inventory.setItem(53, saveItem);
        
        // Load existing items
        if (giftcode.contains(code + ".Item")) {
            for (String itemKey : giftcode.getConfigurationSection(code + ".Item").getKeys(false)) {
                ItemStack item = giftcode.getItemStack(code + ".Item." + itemKey);
                if (item != null) {
                    inventory.addItem(item);
                }
            }
        }
        
        player.openInventory(inventory);
    }
    
    /**
     * Creates the limit item based on giftcode type
     */
    private ItemStack createLimitItem(String code, RandomValue limit) {
        String type = giftcode.getString(code + ".Type", "normal");
        
        if (type.equals("random")) {
            Material material = Material.valueOf(config.getString("Settings.Gui.Items.Random.Material", "PAPER"));
            String name = config.getString("Settings.Gui.Items.Random.Name", "&f&lRandom: &c&l<random>")
                    .replace("<random>", limit.toString());
            List<String> lore = config.getStringList("Settings.Gui.Items.Random.Lore");
            return ItemBuilder.create(material, 1, 0, name, lore);
        } else {
            Material material = Material.valueOf(config.getString("Settings.Gui.Items.Limit.Material", "PAPER"));
            String name = config.getString("Settings.Gui.Items.Limit.Name", "&f&lLimit: &c&l<limit>")
                    .replace("<limit>", limit.toString());
            List<String> lore = config.getStringList("Settings.Gui.Items.Limit.Lore");
            return ItemBuilder.create(material, 1, 0, name, lore);
        }
    }
    
    /**
     * Gets a message from config with prefix
     */
    private String getMessage(String key) {
        String prefix = Utils.colorize(config.getString("Message.Prefix", "&8[&e&lGiftcode&8]"));
        String message = config.getString("Message." + key, "&cMessage not found: " + key);
        return Utils.colorize(message.replace("<prefix>", prefix));
    }
    
    // Event Handlers
    
    @EventHandler(priority = EventPriority.LOWEST)
    public void onAsyncPlayerChat(AsyncPlayerChatEvent event) {
        Player player = event.getPlayer();
        String playerName = player.getName();
        
        if (!editSessions.containsKey(playerName)) {
            return;
        }
        
        String session = editSessions.get(playerName);
        String[] parts = session.split(":");
        if (parts.length != 2) {
            editSessions.remove(playerName);
            return;
        }
        
        String code = parts[0];
        String editType = parts[1];
        
        String message = event.getMessage().toLowerCase();
        
        if (message.equals("huy")) {
            event.setCancelled(true);
            editSessions.put(playerName, code + ":none");
            schedulePlayerTask(player, () -> openGiftcodeGUI(player, code), 1L);
            return;
        }
        
        event.setCancelled(true);

        try {
            processEditInput(player, code, editType, event.getMessage());
        } catch (Exception e) {
            player.sendMessage(Utils.colorize(getMessage("FormatError")));
            getLogger().log(Level.WARNING, "Error processing edit input", e);
        }

        // Chỉ mở lại GUI nếu phiên chỉnh sửa vẫn tồn tại
        if (editSessions.containsKey(playerName)) {
            schedulePlayerTask(player, () -> openGiftcodeGUI(player, code), 1L);
        } else {
            // Đóng GUI nếu đã hoàn tất
            schedulePlayerTask(player, () -> player.closeInventory(), 1L);
        }
    }
    
    /**
     * Processes chat input for editing giftcodes
     */
    private void processEditInput(Player player, String code, String editType, String input) {
        String codeType = giftcode.getString(code + ".Type", "normal");
        
        switch (editType) {
            case "money":
                RandomValue moneyValue = new RandomValue(input);
                if (codeType.equals("random")) {
                    giftcode.set(code + ".Money", moneyValue.toString());
                } else {
                    giftcode.set(code + ".Money", moneyValue.getValue());
                }
                break;
                
            case "points":
                RandomValue pointsValue = new RandomValue(input);
                if (codeType.equals("random")) {
                    giftcode.set(code + ".Points", pointsValue.toString());
                } else {
                    giftcode.set(code + ".Points", pointsValue.getValue());
                }
                break;
                
            case "exp":
                RandomValue expValue = new RandomValue(input);
                if (codeType.equals("random")) {
                    giftcode.set(code + ".Exp", expValue.toString());
                } else {
                    giftcode.set(code + ".Exp", expValue.getValue());
                }
                break;
                
            case "limit":
                RandomValue limitValue = new RandomValue(input);
                if (codeType.equals("random")) {
                    giftcode.set(code + ".Limit", limitValue.toString());
                } else {
                    giftcode.set(code + ".Limit", limitValue.getValue());
                }
                break;
                
            case "online":
                int onlineHours = Utils.parseInt(input, 24);
                giftcode.set(code + ".RequireOnline", onlineHours);
                break;
                
            case "done":
                int value = Utils.parseInt(input, 1);
                if (codeType.equals("normal")) {
                    // Set expiry date
                    SimpleDateFormat sdf = new SimpleDateFormat("HH:mm:ss dd-MM-yyyy");
                    Calendar calendar = Calendar.getInstance();
                    calendar.add(Calendar.DAY_OF_YEAR, value);
                    giftcode.set(code + ".Expired", sdf.format(calendar.getTime()));
                    
                    // Set default command
                    List<String> commands = new ArrayList<>();
                    commands.add("msg <player> Bạn đã nhập giftcode thành công!");
                    giftcode.set(code + ".Command", commands);
                    
                } else if (codeType.equals("limit")) {
                    giftcode.set(code + ".MaxUse", value);
                    
                    // Set default command
                    List<String> commands = new ArrayList<>();
                    commands.add("msg <player> Bạn đã nhập giftcode thành công!");
                    giftcode.set(code + ".Command", commands);
                }
                
                saveConfigurations();
                player.sendMessage(Utils.colorize(getMessage("SaveCode")));
                editSessions.remove(player.getName());
                return;
        }
        
        saveConfigurations();
        editSessions.put(player.getName(), code + ":none");
    }
    
    @EventHandler
    public void onInventoryClick(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player)) return;
        
        Player player = (Player) event.getWhoClicked();
        String title = Utils.colorize(config.getString("Settings.Gui.Title", "&8Genz-Giftcode | Thiết lập phần thưởng"));
        
        if (!event.getView().getTitle().equals(title)) {
            return;
        }
        
        if (event.getClickedInventory() != event.getView().getTopInventory()) {
            return;
        }
        
        String session = editSessions.get(player.getName());
        if (session == null) {
            event.setCancelled(true);
            return;
        }
        
        String[] parts = session.split(":");
        String code = parts[0];
        int slot = event.getSlot();
        
        // Handle border slots
        if (isFillerSlot(slot)) {
            event.setCancelled(true);
            return;
        }
        
        // Handle action buttons
        switch (slot) {
            case 45: // Cancel/Delete
                event.setCancelled(true);
                giftcode.set(code, null);
                saveConfigurations();
                editSessions.remove(player.getName());
                player.sendMessage(Utils.colorize(getMessage("DeleteCode")));
                player.closeInventory();
                break;
                
            case 46: // Require Online
                event.setCancelled(true);
                editSessions.put(player.getName(), code + ":online");
                player.sendMessage(Utils.colorize(getMessage("TypingValue")));
                player.closeInventory();
                break;
                
            case 47: // Money
                event.setCancelled(true);
                editSessions.put(player.getName(), code + ":money");
                player.sendMessage(Utils.colorize(getMessage("TypingValue")));
                player.closeInventory();
                break;
                
            case 49: // Points
                event.setCancelled(true);
                editSessions.put(player.getName(), code + ":points");
                player.sendMessage(Utils.colorize(getMessage("TypingValue")));
                player.closeInventory();
                break;
                
            case 51: // Exp
                event.setCancelled(true);
                editSessions.put(player.getName(), code + ":exp");
                player.sendMessage(Utils.colorize(getMessage("TypingValue")));
                player.closeInventory();
                break;
                
            case 52: // Limit
                event.setCancelled(true);
                editSessions.put(player.getName(), code + ":limit");
                player.sendMessage(Utils.colorize(getMessage("TypingValue")));
                player.closeInventory();
                break;
                
            case 53: // Save
                event.setCancelled(true);
                saveInventoryItems(player, code, event.getInventory());
                finalizeSaveProcess(player, code);
                break;
                
            default:
                // Allow item management in other slots
                break;
        }
    }
    
    /**
     * Checks if a slot is a filler slot
     */
    private boolean isFillerSlot(int slot) {
        return (slot >= 0 && slot <= 8) || slot == 17 || slot == 18 || slot == 26 ||
               slot == 27 || slot == 35 || slot == 36 || slot == 44 || slot == 48 || slot == 50;
    }
    
    /**
     * Saves inventory items to giftcode data
     */
    private void saveInventoryItems(Player player, String code, Inventory inventory) {
        giftcode.set(code + ".Item", null);
        
        for (int slot : itemSlots) {
            ItemStack item = inventory.getItem(slot);
            if (item != null && item.getType() != Material.AIR) {
                giftcode.set(code + ".Item." + slot, item);
            }
        }
    }
    
    /**
     * Finalizes the save process for different giftcode types
     */
    private void finalizeSaveProcess(Player player, String code) {
        String type = giftcode.getString(code + ".Type", "normal");
        
        switch (type) {
            case "normal":
                if (!giftcode.contains(code + ".Expired")) {
                    editSessions.put(player.getName(), code + ":done");
                    player.sendMessage(Utils.colorize(getMessage("TypingCodeExpired")));
                    player.closeInventory();
                    return;
                }
                break;

            case "random":
                if (giftcode.get(code + ".Giftcode") == null) {
                    generateRandomCodes(code);
                }
                break;

            case "limit":
                if (!giftcode.contains(code + ".MaxUse")) {
                    editSessions.put(player.getName(), code + ":done");
                    player.sendMessage(Utils.colorize(getMessage("TypingCodeMaxUse")));
                    player.closeInventory();
                    return;
                }
                break;
        }
        
        saveConfigurations();
        editSessions.remove(player.getName());
        player.sendMessage(Utils.colorize(getMessage("SaveCode")));
        player.closeInventory();
    }
    
    /**
     * Generates random codes for random type giftcodes
     */
    private void generateRandomCodes(String mainCode) {
        int codeCount = config.getInt("Settings.CodeRandom", 10);
        List<String> generatedCodes = new ArrayList<>();
        
        for (int i = 0; i < codeCount; i++) {
            String randomCode = Utils.generateRandomCode(giftcodeFormat);
            generatedCodes.add(randomCode);
        }
        
        giftcode.set(mainCode + ".Giftcode", generatedCodes);
        
        // Set default command
        List<String> commands = new ArrayList<>();
        commands.add("msg <player> Bạn đã nhập giftcode thành công!");
        giftcode.set(mainCode + ".Command", commands);
    }
    
    @EventHandler
    public void onInventoryClose(InventoryCloseEvent event) {
        if (!(event.getPlayer() instanceof Player)) return;
        
        Player player = (Player) event.getPlayer();
        String title = Utils.colorize(config.getString("Settings.Gui.Title", "&8Genz-Giftcode | Thiết lập phần thưởng"));
        
        if (!event.getView().getTitle().equals(title)) {
            return;
        }
        
        String session = editSessions.get(player.getName());
        if (session == null) {
            return;
        }
        
        String[] parts = session.split(":");
        String code = parts[0];
        String editType = parts[1];
        
        // Handle different close scenarios
        switch (editType) {
            case "none":
            case "cancel":
            case "done":
                if (editType.equals("none")) {
                    // Reopen GUI after short delay if closed unexpectedly
                    schedulePlayerTask(player, () -> {
                        if (editSessions.containsKey(player.getName())) {
                            openGiftcodeGUI(player, code);
                        }
                    }, 2L);
                } else if (editType.equals("cancel")) {
                    editSessions.remove(player.getName());
                }
                break;
                
            case "save":
                editSessions.remove(player.getName());
                break;
                
            default:
                // Auto-save items when closing during edit
                saveInventoryItems(player, code, event.getInventory());
                saveConfigurations();
                break;
        }
    }
    
    @EventHandler
    public void onPlayerCommandPreprocess(PlayerCommandPreprocessEvent event) {
        String command = event.getMessage().replaceFirst("/", "");
        String[] parts = command.split(" ");
        
        if (parts.length > 0) {
            String cmd = parts[0].toLowerCase();
            List<String> aliases = config.getStringList("Settings.CommandAliases");
            
            if (aliases.contains(cmd)) {
                StringBuilder newCommand = new StringBuilder("/giftcode");
                for (int i = 1; i < parts.length; i++) {
                    newCommand.append(" ").append(parts[i]);
                }
                event.setMessage(newCommand.toString());
            }
        }
    }
}