package camchua.dhgiftcode;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.MiniMessage;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.ChatColor;

import java.text.DecimalFormat;

/**
 * Utility class for common operations
 */
public final class Utils {

    private static final DecimalFormat DECIMAL_FORMAT = new DecimalFormat("#.#");
    private static final MiniMessage MINI_MESSAGE = MiniMessage.miniMessage();
    private static final LegacyComponentSerializer LEGACY_SERIALIZER = LegacyComponentSerializer.legacyAmpersand();

    private Utils() {} // Utility class

    /**
     * Fixes double precision issues
     * @param d the double to fix
     * @return fixed double
     */
    public static double fixDouble(double d) {
        return Double.parseDouble(DECIMAL_FORMAT.format(d));
    }

    /**
     * Translates color codes using legacy ChatColor
     * @param text the text to translate
     * @return colored text
     */
    public static String colorize(String text) {
        if (text == null) return "";
        return ChatColor.translateAlternateColorCodes('&', text);
    }

    /**
     * Translates modern MiniMessage format to Component
     * @param text the text in MiniMessage format
     * @return Component
     */
    public static Component parseComponent(String text) {
        if (text == null) return Component.empty();
        // Nếu chứa ký tự &, ưu tiên sử dụng legacy format
        if (text.contains("&")) {
            return LEGACY_SERIALIZER.deserialize(text);
        }
        try {
            // First try MiniMessage format
            return MINI_MESSAGE.deserialize(text);
        } catch (Exception e) {
            // Fallback to legacy format
            return LEGACY_SERIALIZER.deserialize(text);
        }
    }

    /**
     * Converts Component to legacy string
     * @param component the component to convert
     * @return legacy formatted string
     */
    public static String toLegacyString(Component component) {
        return LEGACY_SERIALIZER.serialize(component);
    }

    /**
     * Checks if a string is null or empty
     * @param str the string to check
     * @return true if null or empty
     */
    public static boolean isNullOrEmpty(String str) {
        return str == null || str.trim().isEmpty();
    }

    /**
     * Safely parses an integer with default value
     * @param str the string to parse
     * @param defaultValue default value if parsing fails
     * @return parsed integer or default value
     */
    public static int parseInt(String str, int defaultValue) {
        try {
            return Integer.parseInt(str);
        } catch (NumberFormatException e) {
            return defaultValue;
        }
    }

    /**
     * Safely parses a double with default value
     * @param str the string to parse
     * @param defaultValue default value if parsing fails
     * @return parsed double or default value
     */
    public static double parseDouble(String str, double defaultValue) {
        try {
            return Double.parseDouble(str);
        } catch (NumberFormatException e) {
            return defaultValue;
        }
    }

    /**
     * Formats time in hours to a readable string
     * @param hours the hours
     * @return formatted time string
     */
    public static String formatTime(int hours) {
        if (hours == 0) {
            return "0 giờ";
        } else if (hours == 1) {
            return "1 giờ";
        } else if (hours < 24) {
            return hours + " giờ";
        } else {
            int days = hours / 24;
            int remainingHours = hours % 24;
            if (remainingHours == 0) {
                return days + " ngày";
            } else {
                return days + " ngày " + remainingHours + " giờ";
            }
        }
    }

    /**
     * Validates if a string matches the giftcode format
     * @param code the code to validate
     * @param format the expected format (like "XXXX-XXXX-XXXX")
     * @return true if matches format
     */
    public static boolean isValidGiftcodeFormat(String code, String format) {
        if (code == null || format == null) return false;
        
        String regex = format.replaceAll("X", "[A-Z0-9]");
        return code.matches(regex);
    }

    /**
     * Strips color codes from text for console logging
     * @param text the text with color codes
     * @return text without color codes
     */
    public static String stripColors(String text) {
        if (text == null) return "";
        return text.replaceAll("§[0-9a-fk-or]", "");
    }

    /**
     * Generates a random string based on format
     * @param format the format string (like "XXXX-XXXX-XXXX")
     * @return random string matching format
     */
    public static String generateRandomCode(String format) {
        if (format == null) return "";

        StringBuilder result = new StringBuilder();
        String[] characters = {"1", "2", "3", "4", "5", "6", "7", "8", "9", "0",
                              "Q", "W", "E", "R", "T", "Y", "U", "I", "O", "P",
                              "A", "S", "D", "F", "G", "H", "J", "K", "L",
                              "Z", "X", "C", "V", "B", "N", "M"};

        for (char c : format.toCharArray()) {
            if (c == 'X') {
                result.append(characters[(int) (Math.random() * characters.length)]);
            } else {
                result.append(c);
            }
        }

        return result.toString();
    }
}